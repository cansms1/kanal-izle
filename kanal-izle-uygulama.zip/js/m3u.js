// M3U ayrıştırıcı: metinden kanal listesi çıkarır.

function nitelik(satir, ad) {
  const m = new RegExp(`${ad}="([^"]*)"`).exec(satir);
  return m && m[1] !== '' ? m[1] : undefined;
}

// Satırdaki ilk tırnak dışı virgülün indeksi (yoksa -1).
function ilkVirgul(satir) {
  let tirnakta = false;
  for (let i = 0; i < satir.length; i++) {
    const c = satir[i];
    if (c === '"') tirnakta = !tirnakta;
    else if (c === ',' && !tirnakta) return i;
  }
  return -1;
}

export function m3uAyristir(metin) {
  const kanallar = [];
  let atlanan = 0;
  const satirlar = String(metin ?? '').replace(/^﻿/, '').replace(/\r/g, '').split('\n');
  let bekleyen = null;

  for (const ham of satirlar) {
    const satir = ham.trim();
    if (satir === '') continue;
    if (satir.startsWith('#EXTINF')) {
      if (bekleyen) atlanan++;
      const v = ilkVirgul(satir);
      bekleyen = { ad: v >= 0 ? satir.slice(v + 1).trim() : '', satir };
    } else if (satir.startsWith('#')) {
      continue;
    } else if (bekleyen) {
      const { ad, satir: inf } = bekleyen;
      const logo = nitelik(inf, 'tvg-logo');
      const grup = nitelik(inf, 'group-title');
      kanallar.push({
        ad,
        adres: satir,
        ...(logo !== undefined && { logo }),
        ...(grup !== undefined && { grup }),
      });
      bekleyen = null;
    }
  }
  if (bekleyen) atlanan++;
  return { kanallar, atlanan };
}
