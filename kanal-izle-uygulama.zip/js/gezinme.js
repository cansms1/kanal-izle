// Gösterilen listede önceki/sonraki kanalı bulur (uçlarda başa/sona sarar).

export function komsuKanal(liste, adres, yon) {
  if (liste.length === 0) return null;
  const i = liste.findIndex((k) => k.adres === adres);
  if (i === -1) return yon > 0 ? liste[0] : liste[liste.length - 1];
  return liste[(i + yon + liste.length) % liste.length];
}
