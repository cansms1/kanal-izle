// Depolama arka ucu: localStorage kullanılamıyorsa (engelli, hata veriyor) bellek içi yedeğe düşer.

function bellekArka() {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => { m.set(k, String(v)); },
    removeItem: (k) => { m.delete(k); },
  };
}

// `depolama` ya bir depolama nesnesi ya da ona erişen bir fonksiyondur
// (window.localStorage'a erişimin kendisi istisna fırlatabilir).
// Yalnızca erişim ya da okuma (getItem) hata verirse belleğe düşer. Yalnızca yazma hata verirse
// (kota dolu) gerçek depolama korunur; böylece kayıtlı veri görünür kalır ve yazma hatası bildirilir.
// Dönüş: { arka, bellekte } (bellekte: kayıtlar kalıcı değil).
export function guvenliArka(depolama) {
  try {
    const d = typeof depolama === 'function' ? depolama() : depolama;
    if (!d) return { arka: bellekArka(), bellekte: true };
    d.getItem('kanalizle:__sinama');
    return { arka: d, bellekte: false };
  } catch {
    return { arka: bellekArka(), bellekte: true };
  }
}
