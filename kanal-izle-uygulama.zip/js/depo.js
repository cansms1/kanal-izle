// localStorage benzeri bir arka uç üzerinde liste, favori, son izlenen ve abonelik depolama.
// Parola, kullanıcı adı veya ödeme verisi asla saklanmaz.

const ANAHTAR = {
  listeler: 'kanalizle:listeler',
  favoriler: 'kanalizle:favoriler',
  sonIzlenen: 'kanalizle:sonIzlenen',
  abonelikler: 'kanalizle:abonelikler',
  tohum: 'kanalizle:abonelikTohumlandi',
};
const SON_IZLENEN_SINIRI = 20;

export function depoOlustur(arka) {
  // Okuma: bozuk JSON, dizi olmayan değer ya da getItem hatasında boş liste.
  function oku(anahtar) {
    try {
      const ham = arka.getItem(anahtar);
      if (ham == null) return [];
      const veri = JSON.parse(ham);
      return Array.isArray(veri) ? veri : [];
    } catch {
      return [];
    }
  }

  // Yazma: hata durumunda istisna fırlatmaz, false döner.
  function yaz(anahtar, deger) {
    try {
      arka.setItem(anahtar, JSON.stringify(deger));
      return true;
    } catch {
      return false;
    }
  }

  return {
    listeleriGetir: () => oku(ANAHTAR.listeler),
    listeKaydet(liste) {
      const digerleri = oku(ANAHTAR.listeler).filter((l) => l.id !== liste.id);
      return yaz(ANAHTAR.listeler, [...digerleri, liste]);
    },
    listeSil(id) {
      return yaz(ANAHTAR.listeler, oku(ANAHTAR.listeler).filter((l) => l.id !== id));
    },

    favorileriGetir: () => oku(ANAHTAR.favoriler),
    favoriDegistir(adres) {
      const mevcut = oku(ANAHTAR.favoriler);
      const favoriydi = mevcut.includes(adres);
      const yeni = favoriydi ? mevcut.filter((a) => a !== adres) : [...mevcut, adres];
      return yaz(ANAHTAR.favoriler, yeni)
        ? { ok: true, favori: !favoriydi }
        : { ok: false, favori: false };
    },

    favorileriTemizle: () => yaz(ANAHTAR.favoriler, []),

    sonIzlenenEkle(kanal) {
      const digerleri = oku(ANAHTAR.sonIzlenen).filter((k) => k.adres !== kanal.adres);
      return yaz(ANAHTAR.sonIzlenen, [kanal, ...digerleri].slice(0, SON_IZLENEN_SINIRI));
    },
    sonIzlenenleriGetir: () => oku(ANAHTAR.sonIzlenen),

    abonelikleriGetir: () => oku(ANAHTAR.abonelikler),
    abonelikEkle(a) {
      const digerleri = oku(ANAHTAR.abonelikler).filter((x) => x.adres !== a.adres);
      return yaz(ANAHTAR.abonelikler, [...digerleri, { ad: a.ad, adres: a.adres }]);
    },
    abonelikSil(adres) {
      return yaz(ANAHTAR.abonelikler, oku(ANAHTAR.abonelikler).filter((x) => x.adres !== adres));
    },
    // Yalnızca bir kez çalışır; sonradan kullanıcı hepsini silse de yeniden eklemez.
    abonelikleriTohumla(varsayilanlar) {
      try {
        if (arka.getItem(ANAHTAR.tohum) != null) return true;
      } catch {
        return false;
      }
      const liste = varsayilanlar.map((a) => ({ ad: a.ad, adres: a.adres }));
      if (!yaz(ANAHTAR.abonelikler, liste)) return false;
      return yaz(ANAHTAR.tohum, true);
    },
  };
}
