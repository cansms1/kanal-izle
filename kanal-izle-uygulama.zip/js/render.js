// HTML üretimi. Liste kullanıcıdan geldiği için eklenen her metin kaçırılır.

export function kacis(metin) {
  return String(metin ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export const KANAL_SINIRI = 300;

// Liste sınırı aşıldıysa kullanıcıya gösterilecek satır; aksi hâlde boş metin.
export function sinirIpucu(toplam, sinir = KANAL_SINIRI) {
  return toplam > sinir ? `İlk ${sinir} kanal gösteriliyor. Diğerleri için arama kutusunu kullan.` : '';
}

// Toplamda en çok `sinir` satır çizer (tüm gruplar birlikte).
export function gruplarHtml(gruplar, favoriSeti, sinir = KANAL_SINIRI) {
  let kalan = sinir;
  let html = '';
  for (const { grup, kanallar } of gruplar) {
    if (kalan <= 0) break;
    const secilen = kanallar.slice(0, kalan);
    if (secilen.length === 0) continue;
    kalan -= secilen.length;
    html += `<section class="grup"><h2>${kacis(grup)}</h2>`;
    for (const k of secilen) {
      const fav = favoriSeti.has(k.adres);
      const logo = typeof k.logo === 'string' && k.logo.startsWith('https://')
        ? `<img class="logo" src="${kacis(k.logo)}" loading="lazy" alt="">`
        : '';
      html +=
        `<div class="kanal" data-adres="${kacis(k.adres)}">` +
        logo +
        `<span class="ad">${kacis(k.ad || k.adres)}</span>` +
        `<button type="button" class="kalp${fav ? ' dolu' : ''}" aria-pressed="${fav}" aria-label="Favori">${fav ? '♥' : '♡'}</button>` +
        `</div>`;
    }
    html += '</section>';
  }
  return html;
}
