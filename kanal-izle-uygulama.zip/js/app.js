// Arayüz bağlama: Canlı TV, Favoriler, arama, favori ve tam ekran oynatıcı.
import { m3uAyristir } from './m3u.js';
import { ara, grupla } from './ara.js';
import { depoOlustur } from './depo.js';
import { gruplarHtml, kacis, KANAL_SINIRI, sinirIpucu } from './render.js';
import { oynat, hataMesaji } from './oynatici.js';
import { komsuKanal } from './gezinme.js';
import { guvenliArka } from './arka.js';
import { ayarlariKur } from './ekranlar/ayarlar.js';
import { aboneliklerKur } from './ekranlar/abonelik.js';
import { youtubeKur } from './ekranlar/youtube.js';

const { arka, bellekte } = guvenliArka(() => window.localStorage);
const depo = depoOlustur(arka);
const $ = (id) => document.getElementById(id);

const BOS_KANAL = "Henüz kanal yok. Kendi listeni eklemek için Ayarlar'daki Liste ekle bölümünü kullan.";
const BOS_FAVORI = 'Henüz favori yok. Bir kanalın yanındaki kalbe dokun.';
const BOS_SONUC = 'Aramanla eşleşen kanal yok.';
const BELLEK_NOTU = 'Bu tarayıcıda kayıt yapılamıyor; eklediklerin kapatınca silinir.';

let hazirKanallar = [];     // data/varsayilan.m3u kanalları
let kanallar = [];          // tüm kanallar (hazır liste + kullanıcı listeleri)
let gosterilen = [];        // ekranda şu an çizilen kanallar (önceki/sonraki bunun içinde gezer)
let aktifKanal = null;
let aktifSekme = 'canli';
let oynatmaNo = 0;

async function hazirListeyiOku() {
  try {
    const yanit = await fetch('data/varsayilan.m3u');
    if (!yanit.ok) return [];
    return m3uAyristir(await yanit.text()).kanallar;
  } catch {
    return [];
  }
}

function kanallariTopla() {
  const gorulen = new Set();
  const hepsi = [];
  const listeler = depo.listeleriGetir();
  for (const k of [...hazirKanallar, ...listeler.flatMap((l) => (Array.isArray(l.kanallar) ? l.kanallar : []))]) {
    if (!k || !k.adres || gorulen.has(k.adres)) continue;
    gorulen.add(k.adres);
    hepsi.push(k);
  }
  return hepsi;
}

function bildir(metin, sure = 3000) {
  const kutu = $('bildirim');
  kutu.textContent = metin;
  kutu.hidden = false;
  clearTimeout(bildir.zaman);
  bildir.zaman = setTimeout(() => { kutu.hidden = true; }, sure);
}

function listeyiCiz(kutuId, kanalListesi, bosMetin) {
  const kutu = $(kutuId);
  const gruplar = grupla(kanalListesi);
  const favoriSeti = new Set(depo.favorileriGetir());
  if (kanalListesi.length === 0) {
    kutu.innerHTML = `<p class="bos">${kacis(bosMetin)}</p>`;
    return [];
  }
  kutu.innerHTML = gruplarHtml(gruplar, favoriSeti);
  return gruplar.flatMap((g) => g.kanallar).slice(0, KANAL_SINIRI);
}

function canliyiCiz() {
  const sorgu = $('arama').value;
  const bos = kanallar.length === 0 ? BOS_KANAL : BOS_SONUC;
  const sonuc = ara(kanallar, sorgu, KANAL_SINIRI + 1);
  const ipucu = sinirIpucu(sonuc.length);
  $('canliIpucu').textContent = ipucu;
  $('canliIpucu').hidden = ipucu === '';
  gosterilen = listeyiCiz('canliListe', sonuc.slice(0, KANAL_SINIRI), bos);
}

function favorileriCiz() {
  const adresler = new Set(depo.favorileriGetir());
  const liste = kanallar.filter((k) => adresler.has(k.adres));
  const mevcut = new Map(kanallar.map((k) => [k.adres, k]));
  const son = depo.sonIzlenenleriGetir().map((k) => k && mevcut.get(k.adres)).filter(Boolean);
  $('sonBolum').hidden = son.length === 0;
  const sonGosterilen = son.length > 0 ? listeyiCiz('sonListe', son, '') : [];
  if (son.length === 0) $('sonListe').replaceChildren();
  let favGosterilen;
  if (liste.length === 0 && son.length > 0) {
    $('favoriListe').replaceChildren();
    favGosterilen = [];
  } else {
    favGosterilen = listeyiCiz('favoriListe', liste, BOS_FAVORI);
  }
  // Önceki/sonraki gezinmesi iki bölümü birlikte dolaşır; aynı kanal iki kez girmez.
  const sonAdresleri = new Set(sonGosterilen.map((k) => k.adres));
  gosterilen = [...sonGosterilen, ...favGosterilen.filter((k) => !sonAdresleri.has(k.adres))];
}

// Liste eklendi/silindi: kanalları yeniden topla ve açık sekmeyi tazele.
function kanallariYenile() {
  kanallar = kanallariTopla();
  sekmeyiCiz();
}

let ayarlar;
let abonelikler;
let youtube;

function sekmeyiCiz() {
  if (aktifSekme === 'canli') canliyiCiz();
  else if (aktifSekme === 'favoriler') favorileriCiz();
  else if (aktifSekme === 'youtube') youtube.ciz();
  else if (aktifSekme === 'abonelik') abonelikler.ciz();
  else if (aktifSekme === 'ayarlar') ayarlar.ciz();
}

function sekmeSec(ad) {
  aktifSekme = ad;
  for (const s of document.querySelectorAll('.sekme')) s.hidden = s.id !== `sekme-${ad}`;
  for (const d of document.querySelectorAll('#sekmeCubugu button')) {
    if (d.dataset.sekme === ad) d.setAttribute('aria-current', 'page');
    else d.removeAttribute('aria-current');
  }
  sekmeyiCiz();
}

// Önceki yayını kesin olarak durdurur; eski hata işleyicisi de kalmaz.
function yayiniDurdur() {
  const video = $('video');
  video.onerror = null;
  video.pause();
  video.removeAttribute('src');
  video.load();
}

function hataGoster(tur) {
  $('hataMetin').textContent = hataMesaji(tur) || hataMesaji('acilmadi');
  $('hataAlani').hidden = false;
}

function favoriDugmesiniGuncelle() {
  const dugme = $('oynaticiFavori');
  const fav = aktifKanal !== null && depo.favorileriGetir().includes(aktifKanal.adres);
  dugme.textContent = fav ? '♥' : '♡';
  dugme.setAttribute('aria-pressed', String(fav));
  dugme.classList.toggle('dolu', fav);
}

function yayinla() {
  const video = $('video');
  const no = ++oynatmaNo;
  yayiniDurdur();
  $('hataAlani').hidden = true;
  oynat(video, aktifKanal.adres, {
    sayfaProtokolu: window.location.protocol,
    cevrimiciMi: () => navigator.onLine,
    onHata: (tur) => { if (no === oynatmaNo) hataGoster(tur); },
  });
}

function youtubeAlaniniTemizle() {
  $('youtubeAlani').replaceChildren();
  $('youtubeAlani').hidden = true;
  $('oynaticiKatman').removeAttribute('data-tur');
}

function youtubeAc(yayin) {
  oynatmaNo++;
  yayiniDurdur();
  aktifKanal = null;
  $('hataAlani').hidden = true;
  const cerceve = document.createElement('iframe');
  cerceve.src = `https://www.youtube.com/embed/live_stream?channel=${encodeURIComponent(yayin.kanalId)}`;
  cerceve.setAttribute('allow', 'autoplay; fullscreen; picture-in-picture');
  cerceve.setAttribute('allowfullscreen', '');
  cerceve.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
  cerceve.title = yayin.ad;
  $('youtubeAlani').replaceChildren(cerceve);
  $('youtubeAlani').hidden = false;
  $('oynaticiKatman').dataset.tur = 'youtube';
  $('oynaticiAd').textContent = yayin.ad;
  $('oynaticiKatman').hidden = false;
}

function kanalAc(kanal) {
  youtubeAlaniniTemizle();
  aktifKanal = kanal;
  $('oynaticiAd').textContent = kanal.ad || kanal.adres;
  $('oynaticiKatman').hidden = false;
  favoriDugmesiniGuncelle();
  depo.sonIzlenenEkle(kanal);
  yayinla();
}

function oynaticiyiKapat() {
  oynatmaNo++;
  yayiniDurdur();
  $('hataAlani').hidden = true;
  youtubeAlaniniTemizle();
  $('oynaticiKatman').hidden = true;
  aktifKanal = null;
}

function favoriDegistir(adres) {
  const sonuc = depo.favoriDegistir(adres);
  if (!sonuc.ok) bildir('Kaydedilemedi');
  sekmeyiCiz();
  favoriDugmesiniGuncelle();
}

function listeTiklandi(olay) {
  const satir = olay.target.closest('.kanal');
  if (!satir) return;
  const adres = satir.dataset.adres;
  if (olay.target.closest('.kalp')) return favoriDegistir(adres);
  const kanal = kanallar.find((k) => k.adres === adres);
  if (kanal) kanalAc(kanal);
}

function komsuyaGec(yon) {
  if (!aktifKanal) return;
  const sonraki = komsuKanal(gosterilen, aktifKanal.adres, yon);
  if (sonraki) kanalAc(sonraki);
}

async function basla() {
  $('canliListe').addEventListener('click', listeTiklandi);
  $('favoriListe').addEventListener('click', listeTiklandi);
  $('sonListe').addEventListener('click', listeTiklandi);
  $('arama').addEventListener('input', canliyiCiz);
  $('sekmeCubugu').addEventListener('click', (o) => {
    const d = o.target.closest('button[data-sekme]');
    if (d) sekmeSec(d.dataset.sekme);
  });
  $('kapat').addEventListener('click', oynaticiyiKapat);
  $('yenidenDene').addEventListener('click', () => { if (aktifKanal) yayinla(); });
  $('onceki').addEventListener('click', () => komsuyaGec(-1));
  $('sonraki').addEventListener('click', () => komsuyaGec(1));
  $('oynaticiFavori').addEventListener('click', () => { if (aktifKanal) favoriDegistir(aktifKanal.adres); });

  ayarlar = ayarlariKur({ $, depo, bildir, listelerDegisti: kanallariYenile, favorilerDegisti: sekmeyiCiz });
  abonelikler = aboneliklerKur({ $, depo, bildir });
  youtube = youtubeKur({ $, ac: youtubeAc });

  hazirKanallar = await hazirListeyiOku();
  kanallar = kanallariTopla();
  sekmeSec('canli');
  if (bellekte) bildir(BELLEK_NOTU, 8000);

  try {
    const yanit = await fetch('data/abonelikler.json');
    if (yanit.ok) {
      const veri = await yanit.json();
      if (Array.isArray(veri)) depo.abonelikleriTohumla(veri.filter((a) => a && a.ad && a.adres));
    }
  } catch { /* varsayılan abonelikler yüklenemedi; sorun değil */ }
  await youtube.yukle();
  if (aktifSekme === 'abonelik') abonelikler.ciz();
}

basla();
