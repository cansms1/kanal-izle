// Liste ekleme servisi: adres, metin veya dosyadan M3U listesi hazırlar.
import { m3uAyristir } from './m3u.js';

function varsayilanAd(girdi) {
  if (girdi.ad && girdi.ad.trim()) return girdi.ad.trim();
  if (girdi.tur === 'adres') {
    try {
      return new URL(girdi.deger.trim()).host || 'Listem';
    } catch {
      return 'Listem';
    }
  }
  return 'Listem';
}

// FNV-1a 32 bit, onaltılık metin. Kararlı, rastgelelik yok.
function kisaOzet(anahtar) {
  let h = 0x811c9dc5;
  for (let i = 0; i < anahtar.length; i++) {
    h ^= anahtar.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

export async function listeHazirla(girdi, getir = fetch) {
  const deger = typeof girdi.deger === 'string' ? girdi.deger : '';
  if (!deger.trim()) return { ok: false, hata: 'bos' };

  let metin = deger;
  if (girdi.tur === 'adres') {
    try {
      const yanit = await getir(deger.trim());
      if (!yanit.ok) return { ok: false, hata: 'okunamadi' };
      metin = await yanit.text();
    } catch {
      return { ok: false, hata: 'okunamadi' };
    }
  }

  const { kanallar, atlanan } = m3uAyristir(metin);
  const gorulen = new Set();
  const tekil = kanallar.filter((k) => {
    if (gorulen.has(k.adres)) return false;
    gorulen.add(k.adres);
    return true;
  });
  if (tekil.length === 0) return { ok: false, hata: 'gecersiz' };

  // Aynı kaynak aynı id'yi alır; böylece yeniden eklenen liste öncekinin yerine geçer.
  const anahtar = girdi.tur === 'adres'
    ? 'adres:' + deger.trim()
    : 'icerik:' + tekil.map((k) => k.adres).join('\n');

  return {
    ok: true,
    liste: { id: kisaOzet(anahtar), ad: varsayilanAd(girdi), kaynak: girdi.tur, kanallar: tekil },
    atlanan,
  };
}
