// Aboneliklerim: ücretli platformlara kısayollar. Şifre/ödeme alanı yoktur; yayın uygulamada oynatılmaz.
import { kacis } from '../render.js';

export function aboneliklerKur({ $, depo, bildir, ac = (adres) => window.open(adres, '_blank', 'noopener') }) {
  function ciz() {
    const kutu = $('abonelikListe');
    const liste = depo.abonelikleriGetir();
    if (liste.length === 0) {
      kutu.innerHTML = '<p class="bos">Henüz abonelik kısayolu yok.</p>';
      return;
    }
    kutu.innerHTML = liste.map((a) =>
      `<div class="kart" data-adres="${kacis(a.adres)}">` +
      `<span class="ad">${kacis(a.ad)}</span>` +
      `<button type="button" class="ac">Aç</button>` +
      `<button type="button" class="sil" aria-label="Aboneliği sil">Sil</button></div>`
    ).join('');
  }

  function mesaj(metin, hata) {
    const kutu = $('abonelikMesaj');
    kutu.textContent = metin;
    kutu.classList.toggle('hata', hata);
    kutu.hidden = false;
  }

  $('abonelikListe').addEventListener('click', (o) => {
    const kart = o.target.closest('.kart');
    if (!kart) return;
    const adres = kart.dataset.adres;
    if (o.target.closest('.sil')) {
      if (!depo.abonelikSil(adres)) return bildir('Kaydedilemedi');
      return ciz();
    }
    if (o.target.closest('.ac') && adres.startsWith('https://')) ac(adres);
  });

  $('abonelikForm').addEventListener('submit', (o) => {
    o.preventDefault();
    const ad = $('abonelikAd').value.trim();
    const adres = $('abonelikAdres').value.trim();
    if (!ad) return mesaj('Bir ad yaz.', true);
    if (!adres.startsWith('https://') || adres.length <= 'https://'.length) {
      return mesaj('Adres https:// ile başlamalı.', true);
    }
    if (!depo.abonelikEkle({ ad, adres })) return mesaj('Kaydedilemedi', true);
    $('abonelikAd').value = '';
    $('abonelikAdres').value = '';
    mesaj('Abonelik eklendi.', false);
    ciz();
  });

  return { ciz };
}
