// Ayarlar ekranı: Liste ekle (adres / metin / dosya), eklenen listeler, favorileri temizle.
import { listeHazirla } from '../listeler.js';
import { kacis } from '../render.js';

const HATA_MESAJI = {
  bos: 'Boş bir değer girdin. Bir adres, M3U metni ya da dosya ver.',
  gecersiz: 'Bu içerikte geçerli bir kanal bulunamadı. M3U biçiminde olduğundan emin ol.',
  okunamadi: 'Adres okunamadı. Adres yanlış olabilir ya da site tarayıcıdan okunmaya izin vermiyor olabilir. Listenin metnini "Metin yapıştır" ile ekle ya da "Dosya seç" yolunu dene.',
};

function dosyaOku(dosya) {
  return new Promise((coz, red) => {
    const okuyucu = new FileReader();
    okuyucu.onload = () => coz(String(okuyucu.result ?? ''));
    okuyucu.onerror = () => red(okuyucu.error);
    okuyucu.readAsText(dosya);
  });
}

// listelerDegisti: liste eklenince/silinince; favorilerDegisti: favoriler temizlenince.
export function ayarlariKur({ $, depo, bildir, listelerDegisti, favorilerDegisti }) {
  let yol = 'adres';

  function mesajGoster(metin, hata) {
    const kutu = $('listeMesaj');
    kutu.textContent = metin;
    kutu.classList.toggle('hata', hata);
    kutu.hidden = false;
  }

  function yolSec(yeni) {
    yol = yeni;
    for (const d of $('listeYollari').querySelectorAll('button[data-yol]')) {
      d.setAttribute('aria-pressed', String(d.dataset.yol === yol));
    }
    for (const a of $('listeForm').querySelectorAll('[data-yolalani]')) {
      a.hidden = a.dataset.yolalani !== yol;
    }
  }

  function listeleriCiz() {
    const kutu = $('ekliListeler');
    const listeler = depo.listeleriGetir();
    if (listeler.length === 0) {
      kutu.innerHTML = '<p class="bos">Henüz kendi listeni eklemedin.</p>';
      return;
    }
    kutu.innerHTML = listeler.map((l) => {
      const sayi = Array.isArray(l.kanallar) ? l.kanallar.length : 0;
      return `<div class="kart" data-id="${kacis(l.id)}">` +
        `<span class="ad">${kacis(l.ad)}<span class="alt">${sayi} kanal</span></span>` +
        `<button type="button" class="sil" aria-label="Listeyi sil">Sil</button></div>`;
    }).join('');
  }

  async function gonder(olay) {
    olay.preventDefault();
    const dugme = $('listeForm').querySelector('button[type="submit"]');
    dugme.disabled = true;
    try {
      const ad = $('listeAd').value.trim();
      let girdi;
      if (yol === 'adres') {
        girdi = { tur: 'adres', deger: $('listeAdres').value, ad };
      } else if (yol === 'metin') {
        girdi = { tur: 'metin', deger: $('listeMetin').value, ad };
      } else {
        const dosya = $('listeDosya').files[0];
        let metin = '';
        if (dosya) {
          try {
            metin = await dosyaOku(dosya);
          } catch {
            return mesajGoster('Dosya okunamadı. Başka bir dosya dene.', true);
          }
        }
        girdi = { tur: 'dosya', deger: metin, ad: ad || (dosya ? dosya.name : '') };
      }

      mesajGoster('Liste hazırlanıyor…', false);
      const sonuc = await listeHazirla(girdi);
      if (!sonuc.ok) return mesajGoster(HATA_MESAJI[sonuc.hata] || HATA_MESAJI.gecersiz, true);
      if (!depo.listeKaydet(sonuc.liste)) return mesajGoster('Kaydedilemedi', true);

      let metin = `${sonuc.liste.kanallar.length} kanal eklendi`;
      if (sonuc.atlanan > 0) metin += `, ${sonuc.atlanan} satır atlandı`;
      mesajGoster(metin, false);
      $('listeAdres').value = '';
      $('listeMetin').value = '';
      $('listeDosya').value = '';
      $('listeAd').value = '';
      listelerDegisti();
    } finally {
      dugme.disabled = false;
    }
  }

  $('listeYollari').addEventListener('click', (o) => {
    const d = o.target.closest('button[data-yol]');
    if (d) yolSec(d.dataset.yol);
  });
  $('listeForm').addEventListener('submit', gonder);
  $('ekliListeler').addEventListener('click', (o) => {
    if (!o.target.closest('.sil')) return;
    const kart = o.target.closest('.kart');
    if (!kart) return;
    if (!depo.listeSil(kart.dataset.id)) return bildir('Kaydedilemedi');
    listelerDegisti();
  });
  $('favoriTemizle').addEventListener('click', () => {
    if (!depo.favorileriTemizle()) return bildir('Kaydedilemedi');
    bildir('Favoriler temizlendi');
    favorilerDegisti();
  });

  yolSec('adres');
  return { ciz: listeleriCiz };
}
