// YouTube sekmesi: data/youtube.json içindeki resmi canlı yayın kartları.
import { kacis } from '../render.js';

const BOS_YOUTUBE = 'Henüz YouTube yayını eklenmedi.';

export function youtubeKur({ $, ac }) {
  let yayinlar = [];

  function ciz() {
    const kutu = $('youtubeListe');
    if (yayinlar.length === 0) {
      kutu.innerHTML = `<p class="bos">${kacis(BOS_YOUTUBE)}</p>`;
      return;
    }
    kutu.innerHTML = yayinlar.map((y, i) =>
      `<div class="kart tiklanir" data-sira="${i}"><span class="ad">${kacis(y.ad)}</span><span class="ac">İzle</span></div>`
    ).join('');
  }

  async function yukle() {
    try {
      const yanit = await fetch('data/youtube.json');
      if (!yanit.ok) throw new Error('http');
      const veri = await yanit.json();
      yayinlar = Array.isArray(veri)
        ? veri.filter((y) => y && typeof y.ad === 'string' && typeof y.kanalId === 'string' && y.kanalId)
        : [];
    } catch {
      yayinlar = [];
    }
    ciz();
  }

  $('youtubeListe').addEventListener('click', (o) => {
    const kart = o.target.closest('.kart[data-sira]');
    const y = kart && yayinlar[Number(kart.dataset.sira)];
    if (y) ac(y);
  });

  return { ciz, yukle };
}
