// Kanal arama ve gruplama.

// Hem sorgu hem ad aynı işlevle sadeleşir: küçük harf, sonra Türkçe harfler ASCII karşılığına.
const HARITA = { 'ı': 'i', 'ş': 's', 'ğ': 'g', 'ü': 'u', 'ö': 'o', 'ç': 'c' };
const kucult = (metin) =>
  String(metin ?? '').toLocaleLowerCase('tr').replace(/[ışğüöç]/g, (h) => HARITA[h]);

// Ada göre arar (Türkçe harf ve büyük/küçük harf duyarsız); boş sorgu hepsini döndürür. Sonuç sınırlıdır.
export function ara(kanallar, sorgu, sinir = 300) {
  const q = kucult((sorgu ?? '').trim());
  const sonuc = [];
  for (const kanal of kanallar) {
    if (sonuc.length >= sinir) break;
    if (q === '' || kucult(kanal.ad).includes(q)) sonuc.push(kanal);
  }
  return sonuc;
}

// Kanalları gruba göre toplar; grup sırası ilk görülme sırasıdır.
export function grupla(kanallar) {
  const harita = new Map();
  for (const kanal of kanallar) {
    const grup = kanal.grup || 'Diğer';
    if (!harita.has(grup)) harita.set(grup, []);
    harita.get(grup).push(kanal);
  }
  return [...harita].map(([grup, liste]) => ({ grup, kanallar: liste }));
}
