// Oynatıcı mantığı: yalnızca iPhone Safari'nin yerleşik HLS desteği (video.src).

export function hataTuru(adres, sayfaProtokolu) {
  if (sayfaProtokolu === 'https:' && /^http:\/\//i.test(String(adres).trim())) return 'guvensiz';
  return null;
}

const MESAJLAR = {
  guvensiz: "Bu yayın güvenli olmayan adresten geliyor, iPhone'da açılamıyor.",
  acilmadi: 'Bu kanal şu an açılmıyor.',
  internet: 'İnternet bağlantısı yok.',
};

export function hataMesaji(tur) {
  return MESAJLAR[tur];
}

// DOM'a bağlıdır; elle test edilir.
export function oynat(video, adres, { sayfaProtokolu, cevrimiciMi, onHata }) {
  const tur = hataTuru(adres, sayfaProtokolu);
  if (tur) return onHata(tur);
  if (!cevrimiciMi()) return onHata('internet');
  video.setAttribute('playsinline', '');
  video.onerror = () => onHata('acilmadi');
  video.src = adres;
  const sonuc = video.play();
  if (sonuc && typeof sonuc.catch === 'function') sonuc.catch(() => {});
}
